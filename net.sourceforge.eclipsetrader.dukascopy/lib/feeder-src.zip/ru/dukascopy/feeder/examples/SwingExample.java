package ru.dukascopy.feeder.examples;

/**
 * @author Vladimir Pletnyov
 * @version 1.0
 */

import ru.dukascopy.feeder.client.*;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.util.*;


public class SwingExample extends JFrame {

    JTable qTable = new JTable(new DataModel(),new ColumnModel());

    public static void main(String[] args){
        SwingExample sw = new SwingExample();
        sw.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        sw.show();
    }

    public SwingExample() {
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }

    }
  private void jbInit() throws Exception {
    this.setLocation(50,50);
    this.setLocale(java.util.Locale.getDefault());
    this.setResizable(false);
    this.setState(Frame.NORMAL);
    this.setTitle("DUKASCOPY");
    this.setSize(new Dimension(160,188));
    qTable.setAutoscrolls(false);
    this.getContentPane().add(new JScrollPane(qTable), BorderLayout.CENTER);

}

 class DataModel extends javax.swing.table.AbstractTableModel {


      String[] columns = {"Quote","Value",""};
      String[] headers = {"EUR/USD","GBP/USD","NZD/USD","USD/CHF","USD/CAD","USD/JPY","USD/NOK","USD/DKK","USD/SEK"};
      String[] quotes = {"EUR","GBP","NZD","CHF","CAD","JPY","NOK","DKK","SEK"};
      HashMap values = new HashMap();
      HashMap volumes = new HashMap();

      DataModel() {
          this.fireTableDataChanged();
          FeederConnector connector = new FeederConnector();
          for(int i = 0; i < quotes.length; i++){
              connector.addQuote(i,quotes[i]);
          }
          connector.setDataListener(
                  new DataListener() {
                      public void onNewTick(int id, double value, int volume) {
                          setValueAt(new Double(value),id,1);
                          setValueAt(new Integer(volume),id,2);
                          fireTableDataChanged();
                      }
                  }
          );
          connector.connect();
      }

      public Object getValueAt(int row, int column){
          switch(column){
          case 0:
             return " " + headers[row];
          case 1:
              Object test = values.get(new Integer(row));
              return null == test ? "No data" : " " + test;
          case 2:
              test = volumes.get(new Integer(row));
              return null == test ? "" : " " + test;
          }
          return null;
      }

      public void setValueAt(Object obj, int row, int column){
          switch(column){
          case 1:
              values.put(new Integer(row),obj);
              break;
          case 2:
              volumes.put(new Integer(row),obj);
          }
      }


      public int getColumnCount(){
          return columns.length;
      }

      public int getRowCount(){
          return quotes.length;
      }



  }

  class ColumnModel extends DefaultTableColumnModel{

      ColumnModel(){

          TableColumn quote = new TableColumn(0);
          quote.setHeaderValue("Currency");
          quote.setMinWidth(80);
          addColumn(quote);
          TableColumn value = new TableColumn(1);
          value.setHeaderValue("Value");
          value.setMinWidth(50);
          addColumn(value);
          TableColumn volume = new TableColumn(2);
          volume.setMinWidth(30);
          addColumn(volume);

      }

  }

}
