package ru.dukascopy.feeder.examples;

import ru.dukascopy.feeder.client.*;

/**
 * @author Vladimir Pletnyov
 * @version 1.0
 */

public class SimpleExample {

  public static void main(String[] args) {

    FeederConnector connector = new FeederConnector();
    connector.addQuote(1, "MSFT");
    connector.addQuote(2, "EUR");
    connector.addQuote(3, "GBP");
    connector.addQuote(4, "CAD");
    connector.setDataListener(
        new DataListener() {
      public void onNewTick(int id, double value, int volume) {
        System.out.println(value);
      }
    }
    );
    connector.connect();

  }

}