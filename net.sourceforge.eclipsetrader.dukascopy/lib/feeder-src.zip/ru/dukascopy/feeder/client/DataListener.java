package ru.dukascopy.feeder.client;

/**
 * @author Vladimir Pletnyov
 * @version 1.0
 */

public interface DataListener {

    public void onNewTick(int id, double value, int volume);

}