package ru.dukascopy.feeder.client;

import ru.dukascopy.feeder.client.ticker.*;

import java.util.*;

/**
 * @author Vladimir Pletnyov
 * @version 1.0
 */

public class FeederConnector {

    private HashMap quotes = new HashMap();
    private TickerWorker tw = new TickerWorker();
    private Connector conn = new Connector("ticker", tw, true);
    private DataListener listener;

    public FeederConnector() {
        tw.setListener(
                new TickerListener() {
                     public void onNewTick(int id, double value, int volume){
                         if(null != listener) {
                             listener.onNewTick(id,value,volume);
                         }
                     }
                     public void onNewConnection(Connector conn){
                         Iterator itr = quotes.keySet().iterator();
                         while(itr.hasNext()){
                             try{
                                 String code = (String) itr.next();
                                 Integer id = (Integer) quotes.get(code);
                                 conn.sendCommand("connect", code + ":" + id);
                             }
                             catch(Exception ex){}
                         }
                     }
                }

        );
    }

    public void connect() {
        conn.addRoute("datafeed.dukascopy.com",9999);
    }

    public void setDataListener(DataListener listener){
        this.listener = listener;
    }

    public synchronized void addQuote(int id, String code ){
        try{
            quotes.put(code, new Integer(id));
            conn.sendCommand("connect", code + ":" + id);
        }
        catch(Exception ex){
        }
    }

    public synchronized void removeQuote(String code){
        try{
            quotes.remove(code);
            conn.sendCommand("disconnect", code);
        }
        catch(Exception ex){
        }
    }
}