package ru.dukascopy.feeder.client;

/**
 * @author Vladimir Pletnyov
 * @version 1.0
 */

public interface ConnectorWorker {

    public void onNewConnection(Connector conn) throws Exception;
    public void onNewData(Connector conn, String data);
    public void onNewCommand(Connector conn, String command, String data);

}