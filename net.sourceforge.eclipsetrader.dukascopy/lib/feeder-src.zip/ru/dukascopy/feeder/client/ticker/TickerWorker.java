package ru.dukascopy.feeder.client.ticker;

import ru.dukascopy.feeder.client.*;

import java.util.*;

/**
 * @author Vladimir Pletnyov
 * @version 1.0
 */

public class TickerWorker implements ConnectorWorker {

    private TickerListener listener;

    public synchronized void setListener(TickerListener listener){
        this.listener = listener;
    }

    public void onNewConnection(Connector conn){
        if(null != listener){
            listener.onNewConnection(conn);
        }
    }

    public void onNewData(Connector conn, String data){
        try{
            StringTokenizer st = new StringTokenizer(data,",");
            int id = Integer.parseInt(st.nextToken());
            double value = Double.parseDouble(st.nextToken());
            int volume = Integer.parseInt(st.nextToken());
            listener.onNewTick(id,value,volume);
        }
        catch(Exception ex){}
    }

    public void onNewCommand(Connector conn, String command, String data){
        if(command.equals("quotes")) {
            try{
                StringTokenizer st = new StringTokenizer(data,":");
                LinkedList list = new LinkedList();
                while(st.hasMoreTokens()){
                    list.add(st.nextToken());
                }
                conn.set(list);
            }
            catch(Exception ex){}
        }
    }
}