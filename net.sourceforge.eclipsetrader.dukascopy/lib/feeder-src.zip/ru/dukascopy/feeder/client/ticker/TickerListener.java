package ru.dukascopy.feeder.client.ticker;

import ru.dukascopy.feeder.client.Connector;

/**
 * @author Vladimir Pletnyov
 * @version 1.0
 */

public interface TickerListener {

    public void onNewTick(int id, double value, int volume);
    public void onNewConnection(Connector conn);

}