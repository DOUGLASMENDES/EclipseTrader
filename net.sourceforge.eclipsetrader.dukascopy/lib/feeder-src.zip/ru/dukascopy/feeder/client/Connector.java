package ru.dukascopy.feeder.client;

//import ru.dukascopy.router.monitor.Monitor;

import java.util.*;
import java.io.*;
import java.net.*;

/**
 * @author Vladimir Pletnyov
 * @version 1.0
 */

public class Connector {

    public int id = 0;
    public int target = 0;
    private String type;
    private InputStream in;
    private OutputStream out;
    private Socket sock;
    private boolean isConnected = false;
    private ArrayList outgoing = new ArrayList(1000);
    private ArrayList routes = new ArrayList();
    private Route curRoute;
    private OutputThread oThread;
    private InputThread iThread;
    private ConnectorWorker cw;
    private Connector conn = this;
    private int ogSize = 1000;
    private int fast = 0;
    private boolean autoUP = false;
    private Object cObject;

    public Connector (String type, ConnectorWorker cw, boolean autoUP) {

        this.type = type;
        this.cw = cw;
        this.autoUP = autoUP;

    }

    public Connector (int id, String type, ConnectorWorker cw, boolean autoUP) {

        this.id = id;
        this.type = type;
        this.cw = cw;
        this.autoUP = autoUP;

    }

    public void set(Object obj){
        cObject = obj;
    }

    public Object get(){
        return cObject;
    }

    private void autoUP() {
        new Thread(){
            public void run() {
                try{
                    while (!connect()) {
                        sleep(1000);
                    }
                }
                catch(Exception ex){}
            }
        }.start();
    }

    public boolean isConnected(){
        return isConnected;
    }

    public synchronized void addRoute(String host, int port) {
        routes.add(new Route(host, port));
        if(this.autoUP && routes.size() == 1){
            autoUP();
        }
    }

    public boolean connect() {
           if (!isConnected) {
            Iterator itr = routes.iterator();
            while (itr.hasNext()) {
                Route route = (Route) itr.next();
                try {
                    sock = new Socket(route.host, route.port);
                } catch (Exception ex) {
                    continue;
                }
                if (sock.isBound()) {
                    isConnected = true;
                    curRoute = route;
                    break;
                }
            }
        }
        if (isConnected) {
            synchronized (outgoing) {
                outgoing.clear();
                fast = 0;
            }
            oThread = new OutputThread();
            oThread.start();
            iThread = new InputThread();
            iThread.start();
        }
        return isConnected;
    }

    public final void sendCommand(String name, String data) throws Exception {
        String command = "$" + name + "|" + data;
        sendString(command,true);
    }

    public final void sendData(String data, int waitSize) throws Exception {
        while (outgoing.size() >= waitSize) {
            synchronized (outgoing) {
                outgoing.wait();
            }
        }
        sendData(data, false);
    }

    public final void sendData(String data, boolean first) throws Exception {
        String togo = "#" + data;
        synchronized (outgoing) {
            if (outgoing.size() < ogSize) {
                if (first) {
                    outgoing.add(fast++, togo);
                } else {
                    outgoing.add(togo);
                }
                outgoing.notify();
            } else {
                throw new Exception("Buffer overflow");
            }
        }
    }

    public final void sendMessage(String key, String type, String data) throws Exception {
        sendString("@" + key + "|" + type + "|" + data , true);
    }


    private final void sendString(String data, boolean first) throws Exception {
        synchronized (outgoing) {
            if (outgoing.size() < ogSize) {
                if (first) {
                    outgoing.add(fast++, data);
                } else {
                    outgoing.add(data);
                }
                outgoing.notify();
            } else {
                throw new Exception("Buffer overflow");
            }
        }
    }

    public final synchronized void disconnect() {
        this.autoUP = false;
        close();
    }

    private final synchronized void close() {
        if (isConnected) {
            oThread.interrupt();
            iThread.interrupt();
            try {
                sock.shutdownOutput();
                sock.shutdownInput();
                sock.close();
            } catch (Throwable ex) {}
            fast = 0;
            if (autoUP) {
                new Thread(){
                    public void run(){
                        try{
                            while(isConnected){
                                sleep(1000);
                            }
                            while(!connect()){
                                sleep(1000);
                            }
                        }
                        catch(Exception ex){
                        }
                    }
                }.start();
            }
            isConnected = false;
        }
    }


    class OutputThread extends Thread {

        public void run() {
            try {
                out = sock.getOutputStream();
                synchronized(sock){
                    if (id == 0) {
                        out.write((type + "/*/").getBytes());
                    } else {
                        out.write((type + "/" + id + "/").getBytes());
                    }
                    out.flush();
                }
                cw.onNewConnection(conn);
                while (!interrupted()) {
                    while (outgoing.size() != 0) {
                        String data;
                        synchronized (outgoing) {
                            data = outgoing.remove(0).toString();
                            if (fast > 0) {
                                fast--;
                            }
                            outgoing.notify();
                        }
                        out.write(data.getBytes());
                        out.write(0);
                    }
                    synchronized (outgoing) {
                        outgoing.wait();
                    }
                }
            } catch (Throwable ex) {
            }
            close();
        }
    }


    class InputThread extends Thread {

        public void run() {
            try {
                in = sock.getInputStream();
                char com = 0;
                char next;
                int i;
                StringBuffer buffer = new StringBuffer();
                while (((i = in.read()) != -1)) {
                    if ((next = (char) i) == '#' || next == '$' || next == '@' || next == 0) {
                        String data = buffer.toString();
                        if (!data.equals("")) {
                            switch (com) {
                            case '#': //Data
                                cw.onNewData(conn, data);
                                break;
                            case '$': //Command
                                try{
                                    StringTokenizer st = new StringTokenizer(data, "|");
                                    String command = st.nextToken();
                                    String dat = st.nextToken();
                                    cw.onNewCommand(conn, command, dat);
                                }
                                catch(Throwable ex){}
                                break;
                            }
                        }
                        buffer.delete(0, buffer.capacity());
                        com = next;
                    } else {
                        buffer.append(next);
                    }
                }
            } catch (Exception ex) {
            }
            close();
        }
    }

    private class Route {

        int port;
        String host;

        Route(String host, int port) {
            this.host = host;
            this.port = port;
        }

        public final String toString() {
            return host + ":" + port;
        }
    }

}


